<?php
$conn = mysql_connect('localhost', 'root', '');
$db = mysql_select_db('cmpe280');
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$mailid = $_POST['mailid'];

if(mysql_query("INSERT INTO downloadwp VALUES('$fname', '$lname', '$mailid')"))
echo "Successfully Inserted";
else
echo "Insertion Failed";
?>